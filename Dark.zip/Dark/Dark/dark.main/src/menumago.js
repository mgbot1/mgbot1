const menumago = (prefix) => {

	return `
    •----------------------•
       𝘾𝙤𝙢𝙖𝙣𝙙𝙤𝙨 𝘿𝙤 𝙈𝙖𝙜𝙤 💫
    •----------------------•

🇨🇵 *${prefix}fidegermana*
🇨🇵 *${prefix}thiagay*
🇨🇵 *${prefix}herickgay*
🇨🇵 *${prefix}paodoce*
🇨🇵 *${prefix}rafaela*
🇨🇵 *${prefix}fdr*
🇨🇵 *${prefix}bot*
🇨🇵 *${prefix}mago*
🇨🇵 *${prefix}cristina*
🇨🇵 *${prefix}germama*
🇨🇵 *${prefix}roberia*
🇨🇵 *${prefix}bahiano*

--------------------------------
By: 𝘼𝙣𝙙𝙧𝙖𝙙𝙚 𝙈𝙤𝙙𝙙𝙚𝙧 (𝙑𝙪𝙡𝙜𝙤 𝙈𝙖𝙜𝙤) 🤬🔥
--------------------------------`

}
exports.menumago = menumago










