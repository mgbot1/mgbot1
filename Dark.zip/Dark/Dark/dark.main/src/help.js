const help = (prefix) => {
	return `

       •--------------------------•
          🤖 𝙈𝙂𝘽𝙤𝙩 𝙏𝙚𝙨𝙩𝙚 𝙫.3 🤖 
       •--------------------------•


• Prefix:  *「${prefix} 」*
• Status: *「 Teste 」*

         • ---------------- •
              𝘾𝙤𝙢𝙖𝙣𝙙𝙤𝙨 🚀
         • ---------------- •
    
💫 Comando: *${prefix}sticker* ou *${prefix}stiker* (Transforma Imagens Em Figurinhas)

💫 Comando: *${prefix}toimg*
(Transformar Figurinhas Em Imagens)

💫 Comando: *${prefix}meme*
(Memes em Inglês)

💫 Comando: *${prefix}ocr*
(Pega o texto da imagem e envia para você)

💫 Comando: *${prefix}linkgroup*
(O Bot envia o link do grupo, você precisa ser adm e o bot também)

💫 Comando: *${prefix}marcar*
(Marca todos os membros e adms)

💫 Comando: *${prefix}kick*
(Use e o comando e marque a pessoa e ela será removido(a), você e o bot precisa ser adm)

💫 Comando: *${prefix}promote*
(Torna um membro em adm, você e o bot precisa ser adm)

💫 Comando: *${prefix}demote*
(Torna um adm em membro comum, você e o bot precisa ser adm)

💫 Comando: *{prefix}dono*
(Mostra o Dono do bot)

💫 Comando: *{prefix}welcome*
(Bem Vindo do grupo, welcome 1 para ativar e welcome 0 para desativar)

       *Fé Em Deus Família* 💎💙

----------------------------------
  By: 𝘼𝙣𝙙𝙧𝙖𝙙𝙚 𝙈𝙤𝙙𝙙𝙚𝙧 😡🔥
----------------------------------`
}

exports.help = help











